// ============================================
// COURSE DATA
// ============================================

const coursesData = {
    python: [
        { title: "Python Basics", level: "beginner", duration: "4 weeks", desc: "Variables, Data Types & Control Flow" },
        { title: "Python Functions", level: "beginner", duration: "3 weeks", desc: "Define & Master Functions" },
        { title: "OOP in Python", level: "intermediate", duration: "5 weeks", desc: "Classes, Objects & Inheritance" },
        { title: "Python Advanced", level: "advanced", duration: "6 weeks", desc: "Decorators, Async & More" },
    ],
    javascript: [
        { title: "JS Fundamentals", level: "beginner", duration: "4 weeks", desc: "Syntax, Variables & Events" },
        { title: "DOM Manipulation", level: "beginner", duration: "3 weeks", desc: "Master the DOM" },
        { title: "Async JavaScript", level: "intermediate", duration: "5 weeks", desc: "Promises, Async/Await" },
        { title: "Advanced JS", level: "advanced", duration: "6 weeks", desc: "Closures, Prototypes & Patterns" },
    ],
    html: [
        { title: "HTML Basics", level: "beginner", duration: "2 weeks", desc: "Tags, Elements & Structure" },
        { title: "Forms & Validation", level: "beginner", duration: "3 weeks", desc: "Create Powerful Forms" },
        { title: "Semantic HTML", level: "intermediate", duration: "2 weeks", desc: "Best Practices & Accessibility" },
        { title: "HTML Advanced", level: "advanced", duration: "3 weeks", desc: "Canvas, SVG & APIs" },
    ],
    css: [
        { title: "CSS Basics", level: "beginner", duration: "3 weeks", desc: "Selectors, Properties & Values" },
        { title: "Layouts & Flexbox", level: "beginner", duration: "3 weeks", desc: "Master Layouts" },
        { title: "CSS Grid & Animations", level: "intermediate", duration: "4 weeks", desc: "Advanced Layouts & Effects" },
        { title: "CSS Mastery", level: "advanced", duration: "5 weeks", desc: "SASS, Animations & Transformations" },
    ],
    sql: [
        { title: "SQL Basics", level: "beginner", duration: "3 weeks", desc: "SELECT, INSERT & Basic Queries" },
        { title: "Advanced SQL", level: "intermediate", duration: "4 weeks", desc: "Joins, Subqueries & Optimization" },
        { title: "Database Design", level: "intermediate", duration: "5 weeks", desc: "Schema & Normalization" },
        { title: "SQL Mastery", level: "advanced", duration: "6 weeks", desc: "Performance & Complex Queries" },
    ],
    c: [
        { title: "C Basics", level: "beginner", duration: "4 weeks", desc: "Syntax & Fundamentals" },
        { title: "Pointers & Memory", level: "intermediate", duration: "4 weeks", desc: "Master Memory Management" },
        { title: "Data Structures in C", level: "intermediate", duration: "5 weeks", desc: "Arrays, Linked Lists & More" },
        { title: "C Advanced", level: "advanced", duration: "6 weeks", desc: "File I/O & Advanced Concepts" },
    ],
    cpp: [
        { title: "C++ Basics", level: "beginner", duration: "4 weeks", desc: "Introduction to C++" },
        { title: "OOP in C++", level: "intermediate", duration: "5 weeks", desc: "Classes, Inheritance & Polymorphism" },
        { title: "STL & Templates", level: "intermediate", duration: "4 weeks", desc: "Standard Library & Generics" },
        { title: "C++ Advanced", level: "advanced", duration: "6 weeks", desc: "Memory Management & Advanced Features" },
    ],
    java: [
        { title: "Java Basics", level: "beginner", duration: "4 weeks", desc: "JVM & Language Fundamentals" },
        { title: "OOP in Java", level: "beginner", duration: "4 weeks", desc: "Classes, Objects & Inheritance" },
        { title: "Collections & Streams", level: "intermediate", duration: "4 weeks", desc: "Advanced Data Structures" },
        { title: "Java Advanced", level: "advanced", duration: "6 weeks", desc: "Concurrency, Reflection & More" },
    ]
};

const codeTemplates = {
    pythonHello: `# Python Hello World
print("Hello, CodeVerse Hero! 🚀")
print("Welcome to Python!")`,

    pythonLoop: `# Python For Loop
for i in range(1, 6):
    print(f"Number: {i}")`,

    jsHello: `// JavaScript Hello World
console.log("Hello, CodeVerse Hero! 🚀");
console.log("Welcome to JavaScript!");`,

    jsArray: `// JavaScript Array
const heroes = ["Iron Man", "Thor", "Captain America"];
heroes.forEach(hero => console.log(hero));`,

    htmlBasic: `<!DOCTYPE html>
<html>
<head>
    <title>CodeVerse</title>
</head>
<body>
    <h1>Welcome to CodeVerse 🌌</h1>
    <p>Assemble Your Coding Skills</p>
</body>
</html>`,

    htmlForm: `<form>
    <input type="text" placeholder="Your name">
    <input type="email" placeholder="Your email">
    <button type="submit">Submit</button>
</form>`,

    cssStyle: `<style>
    h1 {
        color: #ff006e;
        text-shadow: 0 0 20px #ff006e;
        font-size: 3rem;
    }
    p {
        color: #3a86ff;
        font-size: 1.2rem;
    }
</style>
<h1>CodeVerse</h1>
<p>Marvel Themed Learning</p>`,

    sqlSelect: `-- SQL Basic Query
SELECT * FROM users;

-- SQL With WHERE
SELECT name, email FROM users WHERE age > 18;`
};

// ============================================
// FRIDAY AI CHATBOT
// ============================================

const fridayResponses = {
    hint_syntax: [
        "💡 Check your syntax! Is there a missing semicolon or bracket?",
        "🔍 Look at the error message carefully - it usually tells you exactly where the problem is!",
        "📝 Make sure your function/variable names are spelled correctly.",
        "🎯 Double-check your quotes and parentheses - they need to match!"
    ],
    hint_logic: [
        "🤔 Think about what your code is supposed to do step-by-step.",
        "📊 Try printing out intermediate values to see where it breaks.",
        "🧩 Break your problem into smaller pieces.",
        "🔄 What should happen in each loop iteration?"
    ],
    hint_function: [
        "📚 Does your function accept the right parameters?",
        "🎁 Are you returning the correct value?",
        "🔗 Is the function defined before you call it?",
        "⚙️ Check if all required arguments are being passed."
    ],
    hint_loop: [
        "🔁 What's your loop condition? Will it eventually become false?",
        "🚫 Be careful not to create infinite loops!",
        "📈 What should change in each iteration?",
        "🎯 Is your loop counter being updated?"
    ],
    hint_array: [
        "🗂️ Remember: array indices start at 0, not 1!",
        "📍 Are you accessing the right index?",
        "📊 Have you checked the array length?",
        "🔍 Try using .length to find the size of your array."
    ],
    hint_database: [
        "🗄️ Did you spell your table and column names correctly?",
        "🔑 Use WHERE clause to filter results.",
        "🔗 Are you joining the right tables?",
        "📊 Check your SELECT statement syntax."
    ],
    hint_general: [
        "💪 You got this! Read the error message carefully.",
        "🔄 Try running a simpler version of your code first.",
        "📚 Check the documentation for the function you're using.",
        "🎓 Break the problem down into smaller parts!"
    ]
};

// ============================================
// INITIALIZE PAGE
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    loadCourses('all');
    initChat();
    addCodeEditorListeners();
    loadTemplate('pythonHello');
});

// ============================================
// LOAD COURSES
// ============================================

function filterCourses(level) {
    document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    loadCourses(level);
}

function loadCourses(level) {
    const coursesGrid = document.getElementById('coursesGrid');
    coursesGrid.innerHTML = '';

    const selectedLanguage = document.getElementById('languageSelect')?.value || 'python';
    let courses = coursesData[selectedLanguage] || coursesData.python;

    if (level !== 'all') {
        courses = courses.filter(course => course.level === level);
    }

    courses.forEach(course => {
        const card = document.createElement('div');
        card.className = 'course-card';
        card.innerHTML = `
            <div class="course-header">
                <h3>${course.title}</h3>
                <span class="course-level ${course.level}">${course.level.toUpperCase()}</span>
            </div>
            <p>${course.desc}</p>
            <div class="course-duration">⏱️ Duration: ${course.duration}</div>
            <button class="btn btn-primary" onclick="startCourse('${course.title}')" style="margin-top: 1rem; width: 100%;">
                START HERO'S JOURNEY 🚀
            </button>
        `;
        coursesGrid.appendChild(card);
    });
}

function selectLanguage(lang) {
    const select = document.getElementById('languageSelect');
    if (select) {
        select.value = lang;
        changeLanguage();
    }
}

function changeLanguage() {
    const language = document.getElementById('languageSelect').value;
    loadCourses('all');
    document.getElementById('codeEditor').value = '';
    document.getElementById('output').innerHTML = '';
    
    // Load a template for the selected language
    const templates = {
        python: 'pythonHello',
        javascript: 'jsHello',
        html: 'htmlBasic',
        css: 'cssStyle',
        sql: 'sqlSelect',
        c: 'pythonHello',
        cpp: 'pythonHello',
        java: 'pythonHello'
    };
    
    loadTemplate(templates[language] || 'pythonHello');
}

function startCourse(courseName) {
    addChatMessage('FRIDAY', `Great choice, hero! You're starting "${courseName}" 🎓\n\nRemember:\n✅ Code along with examples\n✅ Ask me for hints when stuck\n✅ Don't ask for direct answers\n✅ Practice makes perfect!\n\nLet's code! 🚀`);
    document.getElementById('chatbotContainer').style.display = 'flex';
}

// ============================================
// CHAT FUNCTIONALITY
// ============================================

function initChat() {
    const chatMessages = document.getElementById('chatMessages');
    chatMessages.innerHTML = '';
    addChatMessage('FRIDAY', `Hey there, Hero! 🦸‍♂️ I'm FRIDAY, your AI Code Guide!\n\nI won't give you answers directly - that would make you weak! 💪 Instead, I'll give you hints and guide you to the solution.\n\n✨ Ask me about:\n• Syntax errors\n• Logic problems\n• How to approach a problem\n• Best practices\n\nLet's assemble your coding skills! 🌌`);
}

function toggleChat() {
    const container = document.getElementById('chatbotContainer');
    container.style.display = container.style.display === 'none' ? 'flex' : 'none';
}

function addChatMessage(sender, message) {
    const chatMessages = document.getElementById('chatMessages');
    const messageEl = document.createElement('div');
    messageEl.className = `chat-message ${sender === 'FRIDAY' ? 'bot' : 'user'}`;
    messageEl.textContent = message;
    chatMessages.appendChild(messageEl);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function handleChatKeypress(event) {
    if (event.key === 'Enter') {
        sendChatMessage();
    }
}

function sendChatMessage() {
    const chatInput = document.getElementById('chatInput');
    const message = chatInput.value.trim();

    if (!message) return;

    addChatMessage('user', message);
    chatInput.value = '';

    // Simulate FRIDAY's response
    setTimeout(() => {
        const response = generateFridayResponse(message);
        addChatMessage('FRIDAY', response);
    }, 500);
}

function generateFridayResponse(userMessage) {
    const msg = userMessage.toLowerCase();
    let response = '';

    if (msg.includes('syntax') || msg.includes('error') || msg.includes('brackets') || msg.includes('semicolon')) {
        response = fridayResponses.hint_syntax[Math.floor(Math.random() * fridayResponses.hint_syntax.length)];
    } else if (msg.includes('loop') || msg.includes('iteration')) {
        response = fridayResponses.hint_loop[Math.floor(Math.random() * fridayResponses.hint_loop.length)];
    } else if (msg.includes('function') || msg.includes('method')) {
        response = fridayResponses.hint_function[Math.floor(Math.random() * fridayResponses.hint_function.length)];
    } else if (msg.includes('array') || msg.includes('list')) {
        response = fridayResponses.hint_array[Math.floor(Math.random() * fridayResponses.hint_array.length)];
    } else if (msg.includes('database') || msg.includes('sql') || msg.includes('table')) {
        response = fridayResponses.hint_database[Math.floor(Math.random() * fridayResponses.hint_database.length)];
    } else if (msg.includes('logic') || msg.includes('wrong') || msg.includes('not working')) {
        response = fridayResponses.hint_logic[Math.floor(Math.random() * fridayResponses.hint_logic.length)];
    } else {
        response = fridayResponses.hint_general[Math.floor(Math.random() * fridayResponses.hint_general.length)];
    }

    return response;
}

// ============================================
// CODE EXECUTION
// ============================================

function addCodeEditorListeners() {
    const editor = document.getElementById('codeEditor');
    if (editor) {
        editor.addEventListener('keydown', function(e) {
            if (e.key === 'Tab') {
                e.preventDefault();
                const start = this.selectionStart;
                const end = this.selectionEnd;
                this.value = this.value.substring(0, start) + '\t' + this.value.substring(end);
                this.selectionStart = this.selectionEnd = start + 1;
            }
        });
    }
}

function loadTemplate(templateName) {
    const template = codeTemplates[templateName];
    if (template) {
        document.getElementById('codeEditor').value = template;
        document.getElementById('output').innerHTML = '';
        document.getElementById('errorPanel').style.display = 'none';
    }
}

function clearCode() {
    document.getElementById('codeEditor').value = '';
    document.getElementById('output').innerHTML = '';
    document.getElementById('errorPanel').style.display = 'none';
}

function runCode() {
    const language = document.getElementById('languageSelect').value;
    const code = document.getElementById('codeEditor').value;
    const outputDiv = document.getElementById('output');
    const errorPanel = document.getElementById('errorPanel');

    outputDiv.innerHTML = '<span style="color: var(--warning);">⚙️ Running code...</span>';
    errorPanel.style.display = 'none';

    // Simulate code execution based on language
    setTimeout(() => {
        try {
            if (language === 'python') {
                executePython(code, outputDiv);
            } else if (language === 'javascript') {
                executeJavaScript(code, outputDiv);
            } else if (language === 'html') {
                executeHTML(code);
            } else if (language === 'css') {
                executeCSS(code);
            } else if (language === 'sql') {
                executeSQL(code, outputDiv);
            } else {
                outputDiv.innerHTML = '<span style="color: var(--warning);">🚀 ' + language.toUpperCase() + ' execution coming soon!</span>';
            }
        } catch (error) {
            showError(error.message, language);
        }
    }, 500);
}

function executePython(code, outputDiv) {
    let output = '';

    // Basic Python simulation
    const lines = code.split('\n');
    for (let line of lines) {
        line = line.trim();
        if (line.startsWith('print(')) {
            const match = line.match(/print\((.*)\)/);
            if (match) {
                let text = match[1].replace(/['"]/g, '').replace(/f['"]/, '');
                output += text + '\n';
            }
        } else if (line.startsWith('for ')) {
            const match = line.match(/for (\w+) in range\((\d+),\s*(\d+)\):/);
            if (match) {
                const [, varName, start, end] = match;
                // This is simplified - just show it would work
                output += `[Loop simulation: ${varName} from ${start} to ${parseInt(end) - 1