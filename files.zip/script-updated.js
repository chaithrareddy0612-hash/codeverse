// ============================================
// COURSE DATA WITH DSA
// ============================================

const coursesData = {
    python: [
        { title: "Python Basics", level: "beginner", duration: "4 weeks", desc: "Variables, Data Types & Control Flow" },
        { title: "Python Functions", level: "beginner", duration: "3 weeks", desc: "Define & Master Functions" },
        { title: "OOP in Python", level: "intermediate", duration: "5 weeks", desc: "Classes, Objects & Inheritance" },
        { title: "Python Advanced", level: "advanced", duration: "6 weeks", desc: "Decorators, Async & More" },
    ],
    javascript: [
        { title: "JS Fundamentals", level: "beginner", duration: "4 weeks", desc: "Syntax, Variables & Events" },
        { title: "DOM Manipulation", level: "beginner", duration: "3 weeks", desc: "Master the DOM" },
        { title: "Async JavaScript", level: "intermediate", duration: "5 weeks", desc: "Promises, Async/Await" },
        { title: "Advanced JS", level: "advanced", duration: "6 weeks", desc: "Closures, Prototypes & Patterns" },
    ],
    html: [
        { title: "HTML Basics", level: "beginner", duration: "2 weeks", desc: "Tags, Elements & Structure" },
        { title: "Forms & Validation", level: "beginner", duration: "3 weeks", desc: "Create Powerful Forms" },
        { title: "Semantic HTML", level: "intermediate", duration: "2 weeks", desc: "Best Practices & Accessibility" },
        { title: "HTML Advanced", level: "advanced", duration: "3 weeks", desc: "Canvas, SVG & APIs" },
    ],
    css: [
        { title: "CSS Basics", level: "beginner", duration: "3 weeks", desc: "Selectors, Properties & Values" },
        { title: "Layouts & Flexbox", level: "beginner", duration: "3 weeks", desc: "Master Layouts" },
        { title: "CSS Grid & Animations", level: "intermediate", duration: "4 weeks", desc: "Advanced Layouts & Effects" },
        { title: "CSS Mastery", level: "advanced", duration: "5 weeks", desc: "SASS, Animations & Transformations" },
    ],
    sql: [
        { title: "SQL Basics", level: "beginner", duration: "3 weeks", desc: "SELECT, INSERT & Basic Queries" },
        { title: "Advanced SQL", level: "intermediate", duration: "4 weeks", desc: "Joins, Subqueries & Optimization" },
        { title: "Database Design", level: "intermediate", duration: "5 weeks", desc: "Schema & Normalization" },
        { title: "SQL Mastery", level: "advanced", duration: "6 weeks", desc: "Performance & Complex Queries" },
    ],
    c: [
        { title: "C Basics", level: "beginner", duration: "4 weeks", desc: "Syntax & Fundamentals" },
        { title: "Pointers & Memory", level: "intermediate", duration: "4 weeks", desc: "Master Memory Management" },
        { title: "Data Structures in C", level: "intermediate", duration: "5 weeks", desc: "Arrays, Linked Lists & More" },
        { title: "C Advanced", level: "advanced", duration: "6 weeks", desc: "File I/O & Advanced Concepts" },
    ],
    cpp: [
        { title: "C++ Basics", level: "beginner", duration: "4 weeks", desc: "Introduction to C++" },
        { title: "OOP in C++", level: "intermediate", duration: "5 weeks", desc: "Classes, Inheritance & Polymorphism" },
        { title: "STL & Templates", level: "intermediate", duration: "4 weeks", desc: "Standard Library & Generics" },
        { title: "C++ Advanced", level: "advanced", duration: "6 weeks", desc: "Memory Management & Advanced Features" },
    ],
    java: [
        { title: "Java Basics", level: "beginner", duration: "4 weeks", desc: "JVM & Language Fundamentals" },
        { title: "OOP in Java", level: "beginner", duration: "4 weeks", desc: "Classes, Objects & Inheritance" },
        { title: "Collections & Streams", level: "intermediate", duration: "4 weeks", desc: "Advanced Data Structures" },
        { title: "Java Advanced", level: "advanced", duration: "6 weeks", desc: "Concurrency, Reflection & More" },
    ],
    dsa: [
        { title: "DSA Foundations", level: "beginner", duration: "5 weeks", desc: "Arrays, Strings & Basics" },
        { title: "Intermediate DSA", level: "intermediate", duration: "6 weeks", desc: "Trees, Graphs & Advanced Structures" },
        { title: "Advanced DSA", level: "intermediate", duration: "5 weeks", desc: "DP, Algorithms & Optimization" },
        { title: "DSA Mastery", level: "advanced", duration: "8 weeks", desc: "Interview Prep & Competitive Programming" },
    ]
};

const codeTemplates = {
    pythonHello: `# Python Hello World
print("Hello, CodeVerse Hero! 🚀")
print("Welcome to Python!")`,

    pythonLoop: `# Python For Loop
for i in range(1, 6):
    print(f"Number: {i}")`,

    jsHello: `// JavaScript Hello World
console.log("Hello, CodeVerse Hero! 🚀");
console.log("Welcome to JavaScript!");`,

    jsArray: `// JavaScript Array
const heroes = ["Iron Man", "Thor", "Captain America"];
heroes.forEach(hero => console.log(hero));`,

    htmlBasic: `<!DOCTYPE html>
<html>
<head>
    <title>CodeVerse</title>
</head>
<body>
    <h1>Welcome to CodeVerse 🌌</h1>
    <p>Assemble Your Coding Skills</p>
</body>
</html>`,

    htmlForm: `<form>
    <input type="text" placeholder="Your name">
    <input type="email" placeholder="Your email">
    <button type="submit">Submit</button>
</form>`,

    cssStyle: `<style>
    h1 {
        color: #ff006e;
        text-shadow: 0 0 20px #ff006e;
        font-size: 3rem;
    }
    p {
        color: #3a86ff;
        font-size: 1.2rem;
    }
</style>
<h1>CodeVerse</h1>
<p>Marvel Themed Learning</p>`,

    sqlSelect: `-- SQL Basic Query
SELECT * FROM users;

-- SQL With WHERE
SELECT name, email FROM users WHERE age > 18;`,

    binarySearch: `# Binary Search in Python
def binary_search(arr, target):
    left, right = 0, len(arr) - 1
    
    while left <= right:
        mid = (left + right) // 2
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            left = mid + 1
        else:
            right = mid - 1
    return -1

# Test
arr = [1, 3, 5, 7, 9, 11]
print(binary_search(arr, 7))  # Output: 3`,

    mergeSort: `# Merge Sort in Python
def merge_sort(arr):
    if len(arr) <= 1:
        return arr
    
    mid = len(arr) // 2
    left = merge_sort(arr[:mid])
    right = merge_sort(arr[mid:])
    
    return merge(left, right)

def merge(left, right):
    result = []
    i = j = 0
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            result.append(left[i])
            i += 1
        else:
            result.append(right[j])
            j += 1
    return result + left[i:] + right[j:]

# Test
arr = [38, 27, 43, 3, 9, 82, 10]
print(merge_sort(arr))`
};

const dsaExamples = {
    'array-basics': `# Array Basics in Python
arr = [1, 2, 3, 4, 5]

# Indexing
print(arr[0])      # 1

# Slicing
print(arr[1:3])    # [2, 3]

# Insert
arr.insert(2, 99)
print(arr)         # [1, 2, 99, 3, 4, 5]

# Delete
arr.pop(2)
print(arr)         # [1, 2, 3, 4, 5]`,

    '2d-array': `# 2D Array (Matrix) in Python
matrix = [
    [1, 2, 3],
    [4, 5, 6],
    [7, 8, 9]
]

# Access element
print(matrix[0][0])    # 1

# Transpose
transposed = [[matrix[j][i] for j in range(3)] for i in range(3)]
for row in transposed:
    print(row)`,

    'sliding-window': `# Sliding Window - Max Sum of Subarray
def max_sum_subarray(arr, k):
    n = len(arr)
    window_sum = sum(arr[:k])
    max_sum = window_sum
    
    for i in range(1, n - k + 1):
        window_sum = window_sum - arr[i - 1] + arr[i + k - 1]
        max_sum = max(max_sum, window_sum)
    
    return max_sum

arr = [1, 4, 2, 10, 2, 3, 1, 0, 20]
k = 4
print(max_sum_subarray(arr, k))  # 24`,

    'prefix-sum': `# Prefix Sum - Range Sum Query
def build_prefix_sum(arr):
    prefix = [0]
    for num in arr:
        prefix.append(prefix[-1] + num)
    return prefix

def range_sum(prefix, left, right):
    return prefix[right + 1] - prefix[left]

arr = [1, 2, 3, 4, 5]
prefix = build_prefix_sum(arr)
print(range_sum(prefix, 1, 3))  # 2+3+4 = 9`,

    'singly-ll': `# Singly Linked List
class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None
    
    def insert(self, data):
        new_node = Node(data)
        new_node.next = self.head
        self.head = new_node
    
    def display(self):
        current = self.head
        while current:
            print(current.data, end=" -> ")
            current = current.next
        print("None")

ll = LinkedList()
ll.insert(3)
ll.insert(2)
ll.insert(1)
ll.display()  # 1 -> 2 -> 3 -> None`,

    'stack-impl': `# Stack Implementation
class Stack:
    def __init__(self):
        self.items = []
    
    def push(self, item):
        self.items.append(item)
    
    def pop(self):
        return self.items.pop() if not self.is_empty() else None
    
    def peek(self):
        return self.items[-1] if not self.is_empty() else None
    
    def is_empty(self):
        return len(self.items) == 0

stack = Stack()
stack.push(1)
stack.push(2)
stack.push(3)
print(stack.pop())   # 3
print(stack.peek())  # 2`,

    'queue-impl': `# Queue Implementation
class Queue:
    def __init__(self):
        self.items = []
    
    def enqueue(self, item):
        self.items.append(item)
    
    def dequeue(self):
        return self.items.pop(0) if not self.is_empty() else None
    
    def is_empty(self):
        return len(self.items) == 0

queue = Queue()
queue.enqueue(1)
queue.enqueue(2)
queue.enqueue(3)
print(queue.dequeue())  # 1
print(queue.dequeue())  # 2`,

    'binary-tree': `# Binary Tree Traversal
class TreeNode:
    def __init__(self, val):
        self.val = val
        self.left = None
        self.right = None

def inorder(node):
    if not node:
        return
    inorder(node.left)
    print(node.val, end=" ")
    inorder(node.right)

# Create tree
root = TreeNode(1)
root.left = TreeNode(2)
root.right = TreeNode(3)

print("Inorder: ")
inorder(root)  # 2 1 3`,

    'bst': `# Binary Search Tree
class BST:
    def __init__(self):
        self.root = None
    
    def insert(self, val):
        if not self.root:
            self.root = TreeNode(val)
        else:
            self._insert_helper(self.root, val)
    
    def _insert_helper(self, node, val):
        if val < node.val:
            if node.left:
                self._insert_helper(node.left, val)
            else:
                node.left = TreeNode(val)
        else:
            if node.right:
                self._insert_helper(node.right, val)
            else:
                node.right = TreeNode(val)`,

    'fibonacci': `# Fibonacci with Dynamic Programming
def fib(n, memo={}):
    if n in memo:
        return memo[n]
    if n <= 1:
        return n
    
    memo[n] = fib(n - 1, memo) + fib(n - 2, memo)
    return memo[n]

for i in range(10):
    print(fib(i), end=" ")  # 0 1 1 2 3 5 8 13 21 34`,

    'knapsack': `# 0/1 Knapsack Problem
def knapsack(W, weights, values, n):
    dp = [[0] * (W + 1) for _ in range(n + 1)]
    
    for i in range(1, n + 1):
        for w in range(1, W + 1):
            if weights[i-1] <= w:
                dp[i][w] = max(
                    values[i-1] + dp[i-1][w-weights[i-1]],
                    dp[i-1][w]
                )
            else:
                dp[i][w] = dp[i-1][w]
    
    return dp[n][W]

W = 10
weights = [5, 4, 6, 3]
values = [10, 40, 30, 50]
print(knapsack(W, weights, values, 4))  # 80`
};

// ============================================
// INITIALIZE PAGE
// ============================================

document.addEventListener('DOMContentLoaded', function() {
    loadCourses('all');
    initChat();
    addCodeEditorListeners();
    loadTemplate('pythonHello');
});

// ============================================
// DSA TAB FUNCTIONALITY
// ============================================

function switchDSATab(tabName) {
    // Hide all tabs
    document.querySelectorAll('.dsa-tab-content').forEach(tab => {
        tab.classList.remove('active');
    });

    // Remove active class from buttons
    document.querySelectorAll('.dsa-tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });

    // Show selected tab
    const selectedTab = document.getElementById(`dsa-${tabName}`);
    if (selectedTab) {
        selectedTab.classList.add('active');
    }

    // Add active class to clicked button
    event.target.classList.add('active');
}

function loadDSAExample(exampleKey) {
    const code = dsaExamples[exampleKey];
    if (code) {
        document.getElementById('codeEditor').value = code;
        document.getElementById('languageSelect').value = 'python';
        document.getElementById('output').innerHTML = '';
        document.getElementById('errorPanel').style.display = 'none';
        
        // Scroll to playground
        document.getElementById('playground').scrollIntoView({ behavior: 'smooth' });
        
        addChatMessage('FRIDAY', `Great choice! 🎓 This is ${exampleKey}!\n\n💡 Key Points:\n• Read the code carefully\n• Understand what each line does\n• Modify and experiment\n• Try running it with different inputs\n\nGo ahead, run the code! 🚀`);
    }
}

function changeAlgorithm() {
    const algo = document.getElementById('algorithmSelect').value;
    const canvas = document.getElementById('visualizerCanvas');
    canvas.innerHTML = `<div class="algo-info">🎨 ${algo.toUpperCase()} Visualizer loaded</div>`;
}

function startVisualization() {
    const canvas = document.getElementById('visualizerCanvas');
    canvas.innerHTML = `<div class="algo-animation">▶ Animation Running...</div>`;
    addChatMessage('FRIDAY', '🎨 Visualization started! Watch how the algorithm works step by step!');
}

function resetVisualization() {
    const canvas = document.getElementById('visualizerCanvas');
    canvas.innerHTML = `<div class="algo-info">🔄 Visualizer Reset</div>`;
}

// ============================================
// LOAD COURSES
// ============================================

function filterCourses(level) {
    document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    loadCourses(level);
}

function loadCourses(level) {
    const coursesGrid = document.getElementById('coursesGrid');
    coursesGrid.innerHTML = '';

    const selectedLanguage = document.getElementById('languageSelect')?.value || 'python';
    let courses = coursesData[selectedLanguage] || coursesData.python;

    if (level !== 'all') {
        courses = courses.filter(course => course.level === level);
    }

    courses.forEach(course => {
        const card = document.createElement('div');
        card.className = 'course-card';
        card.innerHTML = `
            <div class="course-header">
                <h3>${course.title}</h3>
                <span class="course-level ${course.level}">${course.level.toUpperCase()}</span>
            </div>
            <p>${course.desc}</p>
            <div class="course-duration">⏱️ Duration: ${course.duration}</div>
            <button class="btn btn-primary" onclick="startCourse('${course.title}')" style="margin-top: 1rem; width: 100%;">
                START HERO'S JOURNEY 🚀
            </button>
        `;
        coursesGrid.appendChild(card);
    });
}

function selectLanguage(lang) {
    const select = document.getElementById('languageSelect');
    if (select) {
        select.value = lang;
        changeLanguage();
    }
}

function changeLanguage() {
    const language = document.getElementById('languageSelect').value;
    loadCourses('all');
    document.getElementById('codeEditor').value = '';
    document.getElementById('output').innerHTML = '';
    
    const templates = {
        python: 'pythonHello',
        javascript: 'jsHello',
        html: 'htmlBasic',
        css: 'cssStyle',
        sql: 'sqlSelect',
        c: 'pythonHello',
        cpp: 'pythonHello',
        java: 'pythonHello',
        dsa: 'binarySearch'
    };
    
    loadTemplate(templates[language] || 'pythonHello');
}

function startCourse(courseName) {
    addChatMessage('FRIDAY', `🎓 Awesome choice, hero! You're starting "${courseName}"!\n\n✅ Pro Tips:\n• Code along with examples\n• Ask me for hints when stuck\n• Never ask for direct answers\n• Practice is key to mastery!\n\nLet's conquer this! 💪`);
    document.getElementById('chatbotContainer').style.display = 'flex';
}

// ============================================
// CHAT FUNCTIONALITY
// ============================================

const fridayResponses = {
    hint_syntax: [
        "💡 Check your syntax! Is there a missing semicolon or bracket?",
        "🔍 Look at the error message carefully - it usually tells you exactly where the problem is!",
        "📝 Make sure your function/variable names are spelled correctly.",
        "🎯 Double-check your quotes and parentheses - they need to match!"
    ],
    hint_logic: [
        "🤔 Think about what your code is supposed to do step-by-step.",
        "📊 Try printing out intermediate values to see where it breaks.",
        "🧩 Break your problem into smaller pieces.",
        "🔄 What should happen in each loop iteration?"
    ],
    hint_function: [
        "📚 Does your function accept the right parameters?",
        "🎁 Are you returning the correct value?",
        "🔗 Is the function defined before you call it?",
        "⚙️ Check if all required arguments are being passed."
    ],
    hint_loop: [
        "🔁 What's your loop condition? Will it eventually become false?",
        "🚫 Be careful not to create infinite loops!",
        "📈 What should change in each iteration?",
        "🎯 Is your loop counter being updated?"
    ],
    hint_array: [
        "🗂️ Remember: array indices start at 0, not 1!",
        "📍 Are you accessing the right index?",
        "📊 Have you checked the array length?",
        "🔍 Try using .length to find the size of your array."
    ],
    hint_database: [
        "🗄️ Did you spell your table and column names correctly?",
        "🔑 Use WHERE clause to filter results.",
        "🔗 Are you joining the right tables?",
        "📊 Check your SELECT statement syntax."
    ],
    hint_dsa: [
        "🧠 Think about the algorithm step-by-step!",
        "📈 What's the time complexity? Can you optimize?",
        "🔄 Trace through your code with a small example",
        "⚡ Consider edge cases - empty input, single element, etc",
        "📊 Draw a diagram to visualize the problem!",
        "🎯 What's the base case for recursion?"
    ],
    hint_general: [
        "💪 You got this! Read the error message carefully.",
        "🔄 Try running a simpler version of your code first.",
        "📚 Check the documentation for the function you're using.",
        "🎓 Break the problem down into smaller parts!"
    ]
};

function initChat() {
    const chatMessages = document.getElementById('chatMessages');
    chatMessages.innerHTML = '';
    addChatMessage('FRIDAY', `🦸‍♂️ Yo, Hero! I'm FRIDAY, your AI Code Guide!\n\n🚫 I WON'T give you answers directly - that would make you weak!\n\n✨ What I WILL do:\n• Give you hints & clues\n• Point you in the right direction\n• Explain concepts\n• Help you think through problems\n\n💪 This way, YOU become the real hero!\n\nLet's code! 🌌`);
}

function toggleChat() {
    const container = document.getElementById('chatbotContainer');
    container.style.display = container.style.display === 'none' ? 'flex' : 'none';
}

function addChatMessage(sender, message) {
    const chatMessages = document.getElementById('chatMessages');
    const messageEl = document.createElement('div');
    messageEl.className = `chat-message ${sender === 'FRIDAY' ? 'bot' : 'user'}`;
    messageEl.textContent = message;
    chatMessages.appendChild(messageEl);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function handleChatKeypress(event) {
    if (event.key === 'Enter') {
        sendChatMessage();
    }
}

function sendChatMessage() {
    const chatInput = document.getElementById('chatInput');
    const message = chatInput.value.trim();

    if (!message) return;

    addChatMessage('user', message);
    chatInput.value = '';

    setTimeout(() => {
        const response = generateFridayResponse(message);
        addChatMessage('FRIDAY', response);
    }, 500);
}

function generateFridayResponse(userMessage) {
    const msg = userMessage.toLowerCase();
    let response = '';

    if (msg.includes('dsa') || msg.includes('algorithm') || msg.includes('tree') || msg.includes('graph') || msg.includes('dynamic')) {
        response = fridayResponses.hint_dsa[Math.floor(Math.random() * fridayResponses.hint_dsa.length)];
    } else if (msg.includes('syntax') || msg.includes('error') || msg.includes('brackets') || msg.includes('semicolon')) {
        response = fridayResponses.hint_syntax[Math.floor(Math.random() * fridayResponses.hint_syntax.length)];
    } else if (msg.includes('loop') || msg.includes('iteration')) {
        response = fridayResponses.hint_loop[Math.floor(Math.random() * fridayResponses.hint_loop.length)];
    } else if (msg.includes('function') || msg.includes('method')) {
        response = fridayResponses.hint_function[Math.floor(Math.random() * fridayResponses.hint_function.length)];
    } else if (msg.includes('array') || msg.includes('list')) {
        response = fridayResponses.hint_array[Math.floor(Math.random() * fridayResponses.hint_array.length)];
    } else if (msg.includes('database') || msg.includes('sql') || msg.includes('table')) {
        response = fridayResponses.hint_database[Math.floor(Math.random() * fridayResponses.hint_database.length)];
    } else if (msg.includes('logic') || msg.includes('wrong') || msg.includes('not working')) {
        const logicHints = [
            "🤔 Think about what your code is supposed to do step-by-step.",
            "📊 Try printing out intermediate values to see where it breaks.",
            "🧩 Break your problem into smaller pieces.",
            "🔄 What should happen in each iteration?"
        ];
        response = logicHints[Math.floor(Math.random() * logicHints.length)];
    } else {
        response = fridayResponses.hint_general[Math.floor(Math.random() * fridayResponses.hint_general.length)];
    }

    return response;
}

// ============================================
// CODE EXECUTION
// ============================================

function addCodeEditorListeners() {
    const editor = document.getElementById('codeEditor');
    if (editor) {
        editor.addEventListener('keydown', function(e) {
            if (e.key === 'Tab') {
                e.preventDefault();
                const start = this.selectionStart;
                const end = this.selectionEnd;
                this.value = this.value.substring(0, start) + '\t' + this.value.substring(end);
                this.selectionStart = this.selectionEnd = start + 1;
            }
        });
    }
}

function loadTemplate(templateName) {
    const template = codeTemplates[templateName];
    if (template) {
        document.getElementById('codeEditor').value = template;
        document.getElementById('output').innerHTML = '';
        document.getElementById('errorPanel').style.display = 'none';
    }
}

function clearCode() {
    document.getElementById('codeEditor').value = '';
    document.getElementById('output').innerHTML = '';
    document.getElementById('errorPanel').style.display = 'none';
}

function runCode() {
    const language = document.getElementById('languageSelect').value;
    const code = document.getElementById('codeEditor').value;
    const outputDiv = document.getElementById('output');
    const errorPanel = document.getElementById('errorPanel');

    outputDiv.innerHTML = '<span style="color: var(--warning);">⚙️ Running code...</span>';
    errorPanel.style.display = 'none';

    setTimeout(() => {
        try {
            if (language === 'python' || language === 'dsa') {
                executePython(code, outputDiv);
            } else if (language === 'javascript') {
                executeJavaScript(code, outputDiv);
            } else if (language === 'html') {
                executeHTML(code);
            } else if (language === 'css') {
                executeCSS(code);
            } else if (language === 'sql') {
                executeSQL(code, outputDiv);
            } else {
                outputDiv.innerHTML = '<span style="color: var(--warning);">🚀 ' + language.toUpperCase() + ' execution coming soon!</span>';
            }
        } catch (error) {
            showError(error.message, language);
        }
    }, 500);
}

function executePython(code, outputDiv) {
    let output = '';
    const lines = code.split('\n');
    
    for (let line of lines) {
        line = line.trim();
        if (line.startsWith('print(')) {
            const match = line.match(/print\((.*)\)/);
            if (match) {
                let text = match[1].replace(/['"]/g, '').replace(/f['"]/, '');
                output += text + '\n';
            }
        }
    }

    if (output.trim()) {
        outputDiv.innerHTML = `<pre>${output.trim()}</pre>`;
    } else {
        outputDiv.innerHTML = '<span style="color: var(--success);">✅ Code executed successfully!</span>';
    }
}

function executeJavaScript(code, outputDiv) {
    let output = '';
    const originalLog = console.log;
    
    console.log = function(...args) {
        output += args.join(' ') + '\n';
    };

    try {
        eval(code);
        console.log = originalLog;
        
        if (output.trim()) {
            outputDiv.innerHTML = `<pre>${output.trim()}</pre>`;
        } else {
            outputDiv.innerHTML = '<span style="color: var(--success);">✅ Code executed successfully!</span>';
        }
    } catch (error) {
        console.log = originalLog;
        showError(error.message, 'javascript');
    }
}

function executeHTML(code) {
    const newWindow = window.open();
    newWindow.document.write(code);
    newWindow.document.close();
}

function executeCSS(code) {
    const newWindow = window.open();
    newWindow.document.write(code);
    newWindow.document.close();
}

function executeSQL(code, outputDiv) {
    outputDiv.innerHTML = `<span style="color: var(--success);">📊 SQL Query:\n${code}\n\n(Connect to database to see actual results)</span>`;
}

function checkErrors() {
    const code = document.getElementById('codeEditor').value;
    const errorPanel = document.getElementById('errorPanel');
    const errorContent = document.getElementById('errorContent');

    // Basic error checking
    let errors = [];

    if (code.includes('print(') && !code.includes(')')) {
        errors.push('❌ Missing closing parenthesis in print statement');
    }
    if (code.includes('{') && !code.includes('}')) {
        errors.push('❌ Missing closing brace');
    }
    if (code.includes('[') && !code.includes(']')) {
        errors.push('❌ Missing closing bracket');
    }

    if (errors.length > 0) {
        errorPanel.style.display = 'block';
        errorContent.innerHTML = errors.map(e => `<p>${e}</p>`).join('